#!/bin/sh
if patch -p0 -f -s --dry-run < patch_1_2.patch > /dev/null; then
  patch -p0 < patch_1_2.patch
fi
